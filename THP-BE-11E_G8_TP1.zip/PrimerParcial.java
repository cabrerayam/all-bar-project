package clase.thp20210415.parcial;

import java.util.Scanner;

public class PrimerParcial {

	static final Scanner input = new Scanner(System.in);
	static final double COSTO_MOTO = 50;
	static final double COSTO_AUTO = 100;
	static final double COSTO_CAMIONETA = 150;
	static final char MOTO = 'M';
	static final char AUTO = 'A';
	static final char CAMIONETA = 'C';
	static final String FIN_CARGA = "FIN";
	static final int HORA_PICO_MIN = 9;
	static final int HORA_PICO_MAX = 18;
	static final double INCREMENTO_HPICO = 1.5;
	
	public static void main(String[] args) {
		
		String patente;
		char tipoVehiculo;
		int hora;
		int totalAutos;
		int totalVehiculos;
		double valorPeaje;
		double recaudacionTotal;
		double porcAutos;
		boolean horaPico;
		
		// Inicializar
		totalAutos=0;
		totalVehiculos=0;
		recaudacionTotal=0;
		porcAutos=0;
		
		do {
			System.out.println("Ingrese patente");
			patente=input.nextLine().toUpperCase();
		} while(patente.equals(""));
		
		while (!patente.equals(FIN_CARGA)) {
			do {
				System.out.println("Ingrese tipo vehiculo (A-auto, M-moto, C-Camioneta)");
				tipoVehiculo=input.nextLine().toUpperCase().charAt(0);
			} while (tipoVehiculo!=AUTO && tipoVehiculo!=MOTO && tipoVehiculo!=CAMIONETA);
			
			do {
				System.out.println("Ingrese hora");
				hora=Integer.parseInt(input.nextLine());
			} while (hora < 0 || hora > 23);
			
			horaPico = (hora >= HORA_PICO_MIN && hora <=HORA_PICO_MAX);
			
			valorPeaje=0;
			switch (tipoVehiculo) {
			case AUTO:
				totalAutos++;
				valorPeaje = COSTO_AUTO;
				break;
			case MOTO:
				valorPeaje = COSTO_MOTO;
				break;
			case CAMIONETA:
				valorPeaje = COSTO_CAMIONETA;
				break;
			}
			
			if (horaPico) {
				valorPeaje = valorPeaje * INCREMENTO_HPICO;
			}
			
			System.out.println("El vehículo con patente " + patente + " debe pagar $ " + valorPeaje);
			recaudacionTotal += valorPeaje;
			totalVehiculos++;
			
			do {
				System.out.println("Ingrese patente");
				patente=input.nextLine().toUpperCase();
			} while(patente.equals(""));
		}
		
		if (totalVehiculos > 0) {
			porcAutos = (double) totalAutos / totalVehiculos * 100;
			System.out.println("Total recaudado $ " + recaudacionTotal);
			System.out.println("Autos sobre el total " + porcAutos + " %");			
		} else {
			System.out.println("No se ingresaron vehiculos");
		}
		

	}

}
