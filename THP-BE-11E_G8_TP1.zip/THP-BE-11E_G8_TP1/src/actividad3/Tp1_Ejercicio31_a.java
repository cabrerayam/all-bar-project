/*
 * Realiz� un programa que permita validar una opci�n ingresada. Se le preguntar� al usuario si
desea continuar con alguna operaci�n de la forma "�Dese�s continuar? [S/N]" . Se
espera que el usuario ingrese una 'S' o una 'N' (incluir las min�sculas). La opci�n debe ser
ingresada tanto como sea necesario hasta que quede comprendida dentro de las
posibilidades esperadas. Realiz� este ejercicio en dos versiones (A y B): con ciclo while y
con ciclo do - while .
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio31_a {
	
	static final Scanner teclado = new Scanner(System.in);
	static final String SI = "S";
	static final String NO = "N";

	public static void main(String[] args) {
	
		// REALIZAR EL EJERCICIO EN 2 VERSIONES (A y B) C/CICLO WHILE Y DO WHILE
				// RESPECTIVAMENTE

				// VARIABLE P/LEER LA RESPUESTA
				char respuestaUsuario;

				// 1) REALIZAR UN PROGRAMA Q PERMITA VALIDAR UNA OPCION PREVIAMENTE INGRESADA
				// PREGUNTANDO AL USUARIO SI DESEA CONTINUAR C/LA OPERACION DE LA SGTE FORMA:
				// "�DESEA CONTINUAR? (S/N)
				// MUESTRO EN PANTALLA
				System.out.println("PARTE A");
				System.out.print("�Desea continuar? [S/N]: ");

				// LEO EL CARACTER DE LA LA RESPUESTA
				respuestaUsuario = teclado.next().charAt(0);

				// 2) SE ESPERA Q E USUARIO INGRESE UNA 'S' O UNA 'N' INCLUYENDO MINUSCULAS
				// PASO LA RESPUESTA A MAYUSCULA
				respuestaUsuario = Character.toUpperCase(respuestaUsuario);

				// 3) LA OPCION DEBE SER INGRESADA TANTO COMO SEA NECESARIO HASTA Q QEDE
				// COMPRENDIDA DENTRO DE LAS POSIBILIDADES ESPERADAS.
				// MIENTRAS 
				while (respuestaUsuario == 'S') {

					// MUESTRO EN PANTALLA
					System.out.print("�Desea continuar? [S/N]: ");

					// LEO EL CARACTER DE LA LA RESPUESTA
					respuestaUsuario = teclado.next().charAt(0);

					// PASO LA RESPUESTA A MAYUSCULA
					respuestaUsuario = Character.toUpperCase(respuestaUsuario);

					// MIENTRAS RESPUESTA SEA CUALQUIER COSA CONTINUA
				}

				teclado.close();
		
		

	}

}
