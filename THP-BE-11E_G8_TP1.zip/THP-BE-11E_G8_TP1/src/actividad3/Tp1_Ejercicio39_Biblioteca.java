
/*
 La biblioteca de la ciudad necesita organizar y tener un recuento de los libros que
 tiene en sus 5 estantes.
 Por cada uno de los 5 estantes, se ingresan libros:
 Por cada uno de esos libros ingresar:
 - Nombre del libro (�FIN� = No hay m�s libros para ese estante)
 - G�nero (�I�  Infantil, �N�  Novela, �H�  Historia)
 - Cantidad de p�ginas que tiene el libro (mayor a 0)
 Una vez finalizado el ingreso de datos de 1 estante, se debe mostrar por pantalla el
 nombre del libro que m�s p�ginas tiene, con su cantidad correspondiente.
 Al finalizar el ingreso de datos de todos los estantes, mostrar:
 - Cantidad de libros por g�nero
 - Promedio de libros por estante
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio39_Biblioteca {
	
    static final Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {

        //DECLARAR Y DARLES VALOR INICIAL A TODAS LAS VARIABLES
        String nombreLibro = "";
        char generoLibro = ' ';
        int paginasLibro = 0;

        int totalGeneroI = 0;
        int totalGeneroH = 0;
        int totalGeneroN = 0;
        
        int totalLibrosPorEstante = 0;
        int totalLibrosParaTodosLosEstantes = 0;

        int maximoPaginas = Integer.MIN_VALUE;
        String nombreLibroMasPaginas = "";
        
        //ANTES FOR
        for (int estante = 1; estante <= 5; estante++) {
            
            // DURANTE FOR==> PARA CADA ESTANTE 
            maximoPaginas = Integer.MIN_VALUE;
            nombreLibroMasPaginas = "";
            System.out.println("INGRESE LOS LIBROS DEL ESTANTE: " + estante);
            totalLibrosPorEstante = 0;//SE LE DA VALOR INICIAL PARA CADA ESTANTE
            //ANTES DEL WHILE 
            System.out.print("Nombre libro (FIN ==> TERMINAR): ");
            nombreLibro = teclado.next().toUpperCase();
            while (!nombreLibro.equals("FIN")) {
                //DURANTE WHILE ==> PARA CADA LIBRO

                do {//HACER
                    System.out.print("Genero libro: ");
                    generoLibro = teclado.next().charAt(0);
                    //OBTENER LA MAYUSCULA DE LA LETRA
                    generoLibro = Character.toUpperCase(generoLibro);
                    if (generoLibro != 'I' && generoLibro != 'N' && generoLibro != 'H') {
                        System.out.println("ERROR ==> INGRESE UN GENERO VALIDO!!!!");
                    }
                } while (generoLibro != 'I' && generoLibro != 'N' && generoLibro != 'H');//MIENTRAS ERROR!!

                do {//HACER
                    System.out.print("Paginas del libro: ");
                    paginasLibro = teclado.nextInt();
                } while (paginasLibro <= 0); //MIENTRAS ERROR       

                //SEGUN EL GENERO CUENTO LIBROS PARA CADA GENERO
                switch (generoLibro) {
                    case 'I':
                        totalGeneroI ++;
                        break;
                    case 'N':
                        totalGeneroN ++;
                        break;
                    case 'H':
                        totalGeneroH ++;
                        break;
                }
                
                if (paginasLibro > maximoPaginas ) {
                    maximoPaginas = paginasLibro;
                    nombreLibroMasPaginas = nombreLibro;
                }

                totalLibrosPorEstante ++;
                totalLibrosParaTodosLosEstantes ++;
                
                System.out.print("Nombre libro (FIN ==> TERMINAR): ");
                nombreLibro = teclado.next().toUpperCase();
            }//FIN DEL WHILE DE LOS LIBROS
            //DESPUES DEL WHILE ==> TOTALES
            System.out.println("TOTAL DE LIBROS DEL ESTANTE "+estante+ " ES: "+totalLibrosPorEstante);
            if (totalLibrosPorEstante > 0) {
                System.out.println("EL LIBRO DE MAS PAGINAS ES: "+nombreLibroMasPaginas+" CON "+maximoPaginas);
            }
            

        }//FIN DEL FOR DE LOS ESTANTES
        System.out.println("TOTAL DE LIBROS DE GENERO H: "+totalGeneroH);
        System.out.println("TOTAL DE LIBROS DE GENERO I: "+totalGeneroI);
        System.out.println("TOTAL DE LIBROS DE GENERO N: "+totalGeneroN);
        double promedio = totalLibrosParaTodosLosEstantes / 5.0;
        System.out.println("PROMEDIO DE LIBROS POR ESTANTE: "+promedio);
       
        
    }

}
