/*
 *Realiz� un programa que permita ingresar n�meros mientras el promedio entre todos los
ingresados sea menor a 20 . Al terminar el ingreso indicar la cantidad de valores le�dos.
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio36 {
	
	static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
	
		final int prom = 20;
		int num;
		int prome = 00;
		int cant = 1;
		int total = 0;
		
	System.out.println("Ingrese un numero");

	num= input.nextInt();
	total= num + total;
    while (prome < prom) {
		System.out.println("Ingrese otro numero");
	    num = input.nextInt();
	    total = num + total;
	    cant++;
	    prome = total / cant;
	}
	System.out.println("La cantidad de numeros leidos por el programa fue " + cant);
	
	input.close();

	}

}
