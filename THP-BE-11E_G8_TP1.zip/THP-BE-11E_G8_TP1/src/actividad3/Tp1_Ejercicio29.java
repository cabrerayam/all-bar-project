/*Realiz� un programa que permita validar la nota de un examen. 
 * Se espera que la nota que el usuario ingrese sea un n�mero comprendido entre 0 y 10 . 
 * La misma debe ser ingresada tantas veces como sea necesario hasta que quede comprendida
 * dentro del rango indicado.
 * */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio29 {
	
	static final Scanner input = new Scanner(System.in);
	static final int NOTA_MINIMA = 0;
	static final int NOTA_MAXIMA = 10;

	public static void main(String[] args) {
		
		int nota;
		
		System.out.println("Ingrese una nota entre " + NOTA_MINIMA + " y " + NOTA_MAXIMA);
		nota = Integer.parseInt(input.nextLine());
		
		while (nota < NOTA_MINIMA || nota > NOTA_MAXIMA) {
			System.out.println("Nota fuera de rango, por favor ingrese una nota entre " + NOTA_MINIMA + " y " + NOTA_MAXIMA);
			nota = Integer.parseInt(input.nextLine());	
		}
		
		System.out.println("Nota ingresada correctamente: " + nota);
		
		input.close();
			

	}

}
