package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio25 {
	
	static final Scanner teclado  = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		//Declaracion de variables
		int ancho;
		int largo;
	
		// Solicito que ingresen el ancho y el largo
		System.out.println("Ingresa el ancho de la matriz");
		ancho = Integer.parseInt(teclado.nextLine());
		
		System.out.println("Ingresa el largo de la matriz");
		largo = Integer.parseInt(teclado.nextLine());
		
		for (int l = 1 ; l <= largo; l++) {
			for(int a = 1; a <= ancho; a++) {
				System.out.println("x");
			}
			
		System.out.println();

		}
		
		teclado.close();

		
	}

}
