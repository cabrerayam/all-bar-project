/*
 * Realiz� un programa que permita ingresar un n�mero entero n .
 * Debe mostrar los primeros 10 m�ltiplos de n (desde 1 x n ).
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio23 {
	
	static final Scanner input = new Scanner(System.in);
	final static int MULTIPLO = 10;

	public static void main(String[] args) {
		
		int numero;
	
		System.out.println("Por favor ingrese un numero entero: ");
		numero = Integer.parseInt(input.nextLine());
		
		System.out.println("Multiplos de " + numero + " hasta los primeros " + MULTIPLO + " : ");
		for(int i = 1; i <= MULTIPLO; i++) {
			System.out.println(numero * i);
		}
		
		input.close();

	}

}
