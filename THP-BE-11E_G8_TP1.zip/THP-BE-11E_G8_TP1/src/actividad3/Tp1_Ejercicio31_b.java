/*
 * Realiz� un programa que permita validar una opci�n ingresada. Se le preguntar� al usuario si
desea continuar con alguna operaci�n de la forma "�Dese�s continuar? [S/N]" . Se
espera que el usuario ingrese una 'S' o una 'N' (incluir las min�sculas). La opci�n debe ser
ingresada tanto como sea necesario hasta que quede comprendida dentro de las
posibilidades esperadas. Realiz� este ejercicio en dos versiones (A y B): con ciclo while y
con ciclo do - while .
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio31_b {
	
	// VARIABLES ESTATICAS
	static final Scanner teclado = new Scanner(System.in);
	static final String SI = "S";
	static final String NO = "N";

	// REALIZAR EL EJERCICIO EN 2 VERSIONES (A y B) C/CICLO WHILE Y DO WHILE
    // RESPECTIVAMENTE
	
	public static void main(String[] args) {
		
		// PARTE B
				// VARIABLE PARA LEER LA RESPUESTA
				char respuestaUsuario;

				// 1) REALIZAR UN PROGRAMA Q PERMITA VALIDAR UNA OPCION PREVIAMENTE INGRESADA
				// PREGUNTANDO AL USUARIO SI DESEA CONTINUAR C/LA OPERACION DE LA SGTE FORMA:
				// "�DESEA CONTINUAR? (S/N)"
				// MUESTRO EN PANTALLA
				System.out.println("PARTE B");

				// 2) LA OPCION DEBE SER INGRESADA TANTO COMO SEA NECESARIO HASTA Q QEDE
				// COMPRENDIDA DENTRO DE LAS POSIBILIDADES ESPERADAS.
				// HACER
				do {
					// 3) SE ESPERA Q E USUARIO INGRESE UNA 'S' O UNA 'N' (INLCUIR LAS MINUSCULAS)
					// MUESTRO EN PANTALLA
					System.out.print("�Desea continuar? [S/N]: ");

					// LEO EL CARACTER DE LA LA RESPUESTA
					respuestaUsuario = teclado.next().charAt(0);

					// PASO LA RESPUESTA A MAYUSCULA
					respuestaUsuario = Character.toUpperCase(respuestaUsuario);

					// MIENTRAS RESPUESTA SEA S ==> OTRA LETRA TERMINA
				} while (respuestaUsuario == 'S');

				teclado.close();

	}

}
