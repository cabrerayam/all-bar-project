/*
 * Realiz� un programa que permita validar la nota de un examen de la misma manera que el
ejercicio 29 pero con las siguientes nuevas directivas:
- Las notas 1 y 3 no usan nunca.
- La nota 0 se reserva para los ausentes
En resumen, las notas v�lidas pueden ser un 2 o un valor entre 4 y 10 .
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio32 {
	
	static final Scanner input = new Scanner(System.in);
	static final int NOTA_MIN = 2;
	static final int NOTA_MAX = 10;

	public static void main(String[] args) {

			// Declaro variables
			int nota;

			// ingreso de datos validando con un Do While
			do {
				System.out.println("Ingrese una nota");
				nota = Integer.parseInt(input.nextLine());
			} while (nota < NOTA_MIN || nota > NOTA_MAX || nota == 3);

			input.close();

	}

}
