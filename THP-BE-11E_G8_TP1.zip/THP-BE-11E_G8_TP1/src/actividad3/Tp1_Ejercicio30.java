/*
 * Realiz� un programa que permita realizar varias operaciones matem�ticas ingresando un
caracter por cada una la operaci�n a realizar (�+�, �-�, �*�, �/�, �F�) y dos n�meros enteros
en el caso que no haya elegido �F�. 
La computadora debe mostrar el resultado para la operaci�n ingresada.
Considerar que no se puede dividir por cero. Cuando la operaci�n ingresada sea
�F� nos indicar� que no se desean calcular m�s operaciones. [
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio30 {
	
	static final Scanner teclado = new Scanner(System.in);
	static final String SUMA = "+";
	static final String RESTA = "-";
	static final String MULTIPLICA = "*";
	static final String DIVIDE = "/";
	static final String FIN = "FIN";

	public static void main(String[] args) {
		
				String operacion;
				int numero1 = 0;
				int numero2 = 0;
				int resultado = 0;
				String mensajeError = "F";


				System.out.println("Ingrese un operador + - * /, o presione F para finalizar");
				operacion = teclado.nextLine();


				while (!operacion.equals(FIN)) {
					while ((!operacion.equals(SUMA)) && (!operacion.equals(RESTA)) && (!operacion.equals(MULTIPLICA)) && (!operacion.equals(DIVIDE))
							&& (!operacion.equals(FIN))) {
						System.out.println("Ingrese un operador v�lido o salga con F");
						operacion = teclado.nextLine();
					}

					if ((operacion.equals(SUMA)) || (operacion.equals(RESTA)) || (operacion.equals(MULTIPLICA)) || (operacion.equals(DIVIDE))) {
						System.out.println("Ingrese dos numeros enteros");
						numero1 = Integer.parseInt(teclado.nextLine());
						numero2 = Integer.parseInt(teclado.nextLine());
						mensajeError = "";
					} else {
						operacion = FIN;
						
					}


					switch (operacion) {
					case SUMA:
						resultado = numero1 + numero2;
						break;
					case RESTA:
						resultado = numero1 - numero2;
						break;
					case MULTIPLICA:
						resultado = numero1 * numero2;
						break;
					case DIVIDE:
						if (numero2 != 0) {
							resultado = numero1 / numero2;
						} else {
							mensajeError = "Error al dividir por Cero";
						}
						break;
					default:

						break;
					}
					
					// Muestro los resultados analizando si operador fue valido, y no hay error al
					// dividir
					
					if ((operacion.equals(SUMA)) || (operacion.equals(RESTA)) || (operacion.equals(MULTIPLICA)) || (operacion.equals(DIVIDE))) {
						if (mensajeError == "") {
							System.out.println("El resultado es: " + resultado + " " + mensajeError);
						} else {
							System.out.println(mensajeError);
						}
					}
					// Nuevamente pido datos para ingresar nuevamente a operar
					if (!operacion.equals(FIN)) {
						System.out.println("Ha finalizado el programa");
						operacion = teclado.nextLine();
					}

				}
			
				teclado.close();

	}

}
