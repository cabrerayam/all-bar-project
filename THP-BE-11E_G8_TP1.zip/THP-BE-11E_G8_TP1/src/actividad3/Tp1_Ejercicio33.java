/*
 * Realiz� un programa que permita al usuario ingresar n�meros hasta que se introduzca un 0 .
La computadora debe mostrar el n�mero m�ximo y el n�mero m�nimo.
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio33 {
	
	static final Scanner teclado = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		// Declaro variables
				int nro;
				int nroMin;
				int nroMay;

				// Ingreso un dato
				System.out.println("Ingrese un numero, para salir 0");
				nro = Integer.parseInt(teclado.nextLine());

				// Guardo dato en variables
				nroMin = nro;
				nroMay = nro;

				// Proceso el dato ingresado y lo comparo de mayor y menor
				while (nro != 0) {
					if (nro > nroMay) {
						nroMay = nro;
					} else {
						if (nro < nroMin) {
							nroMin = nro;
						}
					}
					// Nuevamente pido ingreso de dato
					System.out.println("Ingrese un numero, para salir 0");
					nro = Integer.parseInt(teclado.nextLine());
				}

				// Muestro el resultado
				System.out.println("El numero menor es: " + nroMin + " y el numero mayor es: " + nroMay);

				teclado.close();
		


	}

}
