 /*Un zool�gico necesita alimentar y obtener informaci�n de un le�n que se encuentra en 
rehabilitaci�n luego de una cirug�a.
Por d�a se alimenta 3 veces a este le�n y por cada tanda se lo alimenta hasta que 
este no tenga m�s ganas de comer.
Cada vez que se le da comida dentro de una tanda se debe ingresar la cantidad en kg 
(numero entero) de alimento que se le dio y se le debe preguntar si quiere seguir 
comiendo('S','N')
-Se desea saber cu�l de las 3 comidas fue la que el Le�n comi� mas Kg de 
alimento y cual fue esa cantidad.
-El total en kg de alimento recibido.
-Promedio de alimento por tanda
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio40_Zoologico {
	
	private static final Scanner TECLADO = new Scanner(System.in);

	public static void main(String[] args) {
	
	       char respuesta;
	       boolean terminaDeComer = false;
	       int kg;
	       kg = 0;
	        
	        for (int comida = 1; comida <= 3; comida++) {
	            System.out.println("COMIDA: "+comida);
	            terminaDeComer = false;
	            do {
	                System.out.print("KG: ");
	                kg = TECLADO.nextInt();
	                
	                System.out.print("CONTINUA COMIENDO ? [S,N]: ");
	                respuesta = TECLADO.next().charAt(0);
	                respuesta = Character.toUpperCase(respuesta);
	                if (respuesta == 'N') {
	                    terminaDeComer = true;
	                }
	                
	            } while (! terminaDeComer);	

	}

	}

}
