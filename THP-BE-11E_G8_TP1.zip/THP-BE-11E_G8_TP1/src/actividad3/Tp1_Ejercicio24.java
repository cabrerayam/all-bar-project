/*
 * Realiz� un programa que permita al usuario ingresar dos n�meros enteros num1 y num2 ,
donde el primero siempre deber� ser menor o igual al segundo. La computadora debe
mostrar la secuencia de n�meros existentes entre ambos:
a. Incluy�ndolos;
b. Excluy�ndolos.
 */

package actividad3;

public class Tp1_Ejercicio24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
