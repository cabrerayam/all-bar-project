/*
 * Realiz� un programa que muestre todos los n�meros enteros del 1 al 5 , y luego los mismos
n�meros pero en orden inverso.
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio22 {
	
	static final Scanner input = new Scanner(System.in);
	static final int BASE = 1;
	static final int TOPE = 5;

	public static void main(String[] args) {
		
		//Imprimo en orden ascendente 
		System.out.println("Valores desde " + BASE + " a " + TOPE + " :");
		for (int i = BASE; i <= TOPE; i++ ) {
			System.out.println(i);
		}
		
		//Imprimo en orden descendente
		System.out.println("Valores desde " + TOPE + " a " + BASE + " :");
		
		for (int i = TOPE; i >= BASE; i--) {
			System.out.println(i);
			
		}
		
	}

}
