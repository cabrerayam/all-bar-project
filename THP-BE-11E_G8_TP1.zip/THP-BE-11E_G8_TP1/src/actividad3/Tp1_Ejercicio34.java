/*Realiz� un programa que permita ingresar la estatura (en metros con decimales) de cada
jugador de un equipo de baloncesto. La carga finalizar� al ingresar cero. Calcular y mostrar la
estatura promedio del equipo*/

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio34 {
	
	static final Scanner input = new Scanner(System.in);
	static final int FIN_CARGA = 0;

	public static void main(String[] args) {
		
		double estaturaJugador, promedioEstatura;
		double acumuladorEstatura = 0;
		int cantJugadores = 0;
		
		System.out.println("Ingrese la estatura del jugador " + (cantJugadores + 1) + " o cero(0) para salir:");
		estaturaJugador = Double.parseDouble(input.nextLine());
		
		while(estaturaJugador != FIN_CARGA) {
			acumuladorEstatura += estaturaJugador;
			cantJugadores++;
			
			System.out.println("Ingrese la estatura del jugador " + (cantJugadores + 1) + " o cero(0) para salir:");
			estaturaJugador = Double.parseDouble(input.nextLine());
		}
		
		if(cantJugadores > 0) {
			promedioEstatura = acumuladorEstatura / cantJugadores;
			System.out.println("La estatura promedio del equipo es: " + promedioEstatura);
			
		} else {
			System.out.println("No se ingresaron datos.");
		}
		
		input.close();

	}

}




