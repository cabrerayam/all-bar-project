/*
 * Realiz� un programa que permita al usuario ingresar hasta 12 valores, de a uno por vez, que
representan los sueldos mensuales que percibi� un empleado durante un a�o calendario. Si
durante la carga de los sueldos mensuales se detecta un valor negativo, esto indica que a�n
no se ha cobrado el mes en curso, y en ese caso se debe dejar de ingresar datos. Al finalizar
mostrar el monto percibido por el empleado hasta ese momento (total o parcial).
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio37 {
	
	static final Scanner input = new Scanner(System.in);
	static final String MENSAJE = "Ingresar el sueldo del mes ";
	static final int ANIO = 12;

	public static void main(String[] args) {

		int mes;
		double sueldo, acumulador;
		
		acumulador = 0;
		mes = 1;
		
		System.out.println(MENSAJE + mes);
		sueldo = Double.parseDouble(input.nextLine());
		
		while(sueldo > 0 && mes < ANIO) {
			acumulador += sueldo;
			mes++;
			
			System.out.println(MENSAJE + mes);
			sueldo = Double.parseDouble(input.nextLine());
		}
		
		acumulador += sueldo;
		
		System.out.println("El monto percibido por el empeado hasta el momento es $" + acumulador);
		
		input.close();

	}

}
