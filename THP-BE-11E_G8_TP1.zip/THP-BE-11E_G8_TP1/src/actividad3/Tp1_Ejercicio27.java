/*
 * Realiz� un programa que permita ingresar 5 edades. 
 * Calcular y mostrar el promedio de todas las edades ingresadas 
 * y cu�ntas edades fueron valores impares mayores que 18
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio27 {
	
	static final Scanner input = new Scanner (System.in);
	static final int EDAD_MAYOR = 18;
	static final int CANTIDAD_EDADES = 5;
	
	public static void main(String[] args) {
		
		int edad;
		double promedio;
		int acumuladorEdades;
		int contadorImpares;
		boolean esImpar;
		
		//Inicializo contadores y acumuladores
		acumuladorEdades = 0;
		contadorImpares = 0;
		
		for(int i = 1; i <= CANTIDAD_EDADES; i++) {
			
			//Ingreso de datos validado con Do While para que se ingrese un valor mayor a cero
			do {
				System.out.println("Ingrese la edad");
				edad = Integer.parseInt(input.nextLine());
			} while(edad < 0);
			
			acumuladorEdades = acumuladorEdades + edad;
			esImpar = (edad % 2 != 0);
			
			//Si es mayor a la edad establecida (18) y es impar sumo 1 al contador de impares
			
			if(edad > EDAD_MAYOR && esImpar) {
				contadorImpares++;
			}
			
		}
		
		promedio = acumuladorEdades / CANTIDAD_EDADES;
		
		//Muestro los datos
		System.out.println("El promedio de las edades ingresadas es " + promedio );
		System.out.println("Las edades mayores a " + EDAD_MAYOR + " e impares son: " + contadorImpares);
		
		input.close();

	}

}
