/*
 * Realiz� un programa que permita ingresar nombre y edad de un grupo de personas (para
cada una, nombre y edad). La carga termina cuando en el nombre de la persona se ingresa un
asterisco ( '*' ). Mostrar al final c�mo se llama la persona m�s joven.
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio35 {
	
	static final Scanner input = new Scanner(System.in);
	static final String FIN_DE_CARGA = "*";

	public static void main(String[] args) {
		
		String nombre;
		int edad;
		String nombreMenor;
		int edadMenor;
		
		System.out.println("Por favor ingrese el nombre");
		nombre = input.nextLine();
		
		edadMenor = Integer.MAX_VALUE; 
		nombreMenor = "";
		
		while (!nombre.equals(FIN_DE_CARGA)) {
			System.out.println("Por favor ingrese la edad");
			edad = Integer.parseInt(input.nextLine());
			if (edad < edadMenor) {
				edadMenor = edad;
				nombreMenor = nombre;
			}
			System.out.println("Por favor ingrese el nombre");
			nombre = input.nextLine();
		}
		
		if (edadMenor == Integer.MAX_VALUE) {
			System.out.println("Por favor ingrese un dato");
		} else {
			System.out.println("La persona con menos edad es " + nombreMenor + " y su edad es " + edadMenor);
		}
		
		input.close();

	}

}
