/*
 * Realiz� un programa que permita al usuario ingresar un n�mero natural n . 
 * La computadora debe mostrar los primeros n m�ltiplos de 3 excepto aquellos que sean 
 * a la vez m�ltiplos de 5
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio26 {
	
	static final Scanner teclado = new Scanner(System.in);
	final static int MULT = 3;
	final static int EVIT = 5;
	final static String MENS1 = "ingrese la cantidad de multiplos de 3 que desea";
	final static String MENS2 = "Los multiplos solicitados son: ";

	public static void main(String[] args) {
		
		// declaraci�n de variables
				int num;
				int cont;
				int rest;
				int control5;
		
		// inicializaci�n de los contadores
				cont = 1;
				
		// Solicito la entrada del numero de multiplos de vueltas for
				
				System.out.println(MENS1);
				num = Integer.parseInt(teclado.nextLine());
			
				System.out.println(MENS2);
				for (int i = 1; i <= num; i++) {
					rest = MULT * cont;
					control5 = rest % EVIT;
					
					if (control5 != 0) {
					System.out.println(rest);
					
					}
					cont++;
				}
				
				System.out.println("Fin de programa");
				teclado.close();
				
			}

}

