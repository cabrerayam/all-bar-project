/*Realiz� un programa que permita controlar con validaci�n el ingreso a un sitio web. 
 * Teniendo ya precargados un nombre de usuario ( "admin" ) y una contrase�a ( "123456" ),
 * el programa debe permitir al usuario ingresar sus credenciales.
 * Si las mismas son err�neas, se volver�n a pedir hasta un m�ximo de 3 intentos. 
 * Finalmente, la computadora debe mostrar alguno de los siguientes mensajes 
 * seg�n sea el caso: "Acceso concedido" o "Se ha bloqueado la cuenta"
 * 
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio38 {
	
	//Declaracion de constantes:
	static final Scanner input = new Scanner(System.in);
	static final String NOMBRE_USUARIO = "admin";
	static final String CONTRASE�A = "123456";
	static final int MAX_INTENTOS = 3;

	public static void main(String[] args) {
		
		//Declaracion de variables:
		String nombreIngresadoUsuario;
		String contrase�aIngresadaUsuario;
		int contIntentos;
		
		//Inicializo el contador
		contIntentos = 1;
		
		//Ingreso de datos por parte del usuario:
		System.out.println("Por favor ingrese su nombre de usuario");
		nombreIngresadoUsuario = input.nextLine();
		System.out.println("Por favor ingrese su contrase�a");
		contrase�aIngresadaUsuario = input.nextLine();
		
		// Proceso los datos ingresados:
		
		while(contIntentos < MAX_INTENTOS && ((!nombreIngresadoUsuario.equals(NOMBRE_USUARIO)) || (!contrase�aIngresadaUsuario.equals(CONTRASE�A))))
			{
			contIntentos++;
			System.out.println("Nombre de usuario o contrase�a incorrecta, intente de nuevo");
			System.out.println("Por favor ingrese su nombre de usuario");
			nombreIngresadoUsuario = input.nextLine();
			System.out.println("Por favor ingrese su contrase�a");
			contrase�aIngresadaUsuario = input.nextLine();
			}
		
		// Muestro resultados sobre el ingreso
		if((nombreIngresadoUsuario.equals(NOMBRE_USUARIO)) && (contrase�aIngresadaUsuario.equals(CONTRASE�A)))
			{
			System.out.println("Acceso concedido");
			
			} else {
				System.out.println("Se ha bloquedo la cuenta");
			}
		
		input.close();
				
	}

}
