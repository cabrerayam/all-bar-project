/*
 * Realiz� un programa que a partir de un n�mero entero cant ingresado por el usuario 
 * permita cargar por teclado cant n�meros enteros. 
 * La computadora debe mostrar cu�l fue el mayor n�mero y en qu� posici�n apareci�.
 */

package actividad3;

import java.util.Scanner;

public class Tp1_Ejercicio28 {
	
	static final Scanner teclado = new Scanner(System.in);
	static final String MENS1 = "Indique la cantidad de ingresos que va a realizar";
	static final String MENS2 = "Ingrese un numero entero";

	public static void main(String[] args) {
		
		//Variables
		int num;
		int alm;
		int may;
		int cont;
	
		//Inicializaci�n de Variables
		may = 0;
		cont = 0;
		
		//Ingreso de datos por parte del usuario
		System.out.println(MENS1);
		num = Integer.parseInt(teclado.nextLine());
		
		//Recolecto los datos
		
		do {
			System.out.println(MENS2);
			alm = Integer.parseInt(teclado.nextLine());
			//Almaceno el mayor
			
			if (alm > may) {
				may = alm;
			}
			
			cont ++;
			
		} while(cont < num);
			//muestro cual fue el mayor numero ingresado
		
		System.out.println("El mayor es: " + may);
		System.out.println("Programa terminado");
		
		teclado.close();
				
	}
		

	}

