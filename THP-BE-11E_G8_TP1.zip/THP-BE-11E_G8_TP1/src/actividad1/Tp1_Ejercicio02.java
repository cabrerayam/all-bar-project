/*
 * Realiz� un programa que permita ingresar 3 notas pertenecientes a tres trimestres distintos para cierto alumno de nivel secundario. Debe calcularse y mostrarse la nota promedio.
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio02 {
	
	static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		int notaTrimestreUno;
		int notaTrimestreDos;
		int notaTrimestreTres;
		double promedio;
		System.out.println("Ingrese la nota del primer trimestre");
		notaTrimestreUno = Integer.parseInt(input.nextLine());
		System.out.println("Ingrese la nota del segundo trimestre");
		notaTrimestreDos = Integer.parseInt(input.nextLine());
		System.out.println("Ingrese la nota del tercer trimestre");
		notaTrimestreTres = Integer.parseInt(input.nextLine());
		promedio = (notaTrimestreUno + notaTrimestreDos + notaTrimestreTres) / 3.0;
		System.out.println("El promedio de la nota es " + promedio);
		input.close();
	}

}
