/*
Realiz� un programa que permita ingresar el valor monetario de una hora de trabajo y 
la cantidad de horas trabajadas por d�a por un trabajador. 
Debes mostrar el valor del salario semanal, 
sabiendo que trabaja todos los d�as h�biles y la mitad de las horas del d�a h�bil los s�bados. 
(Todas las horas valen lo mismo.)
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio04 {
	
	static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
	
		int cantidadHoras;
		double valorHora ; 
		double valorDia;
		double totalDiasHabiles;
		double totalSabados;
		double totalSemanal;
		
		System.out.println("Ingrese el valor de la hora de trabajo");
		valorHora = Double.parseDouble(input.nextLine());
		System.out.println("Ingrese la cantidad de horas trabajadas por d�a h�bil");
		cantidadHoras = Integer.parseInt(input.nextLine());
		
		valorDia = valorHora * cantidadHoras;
		totalDiasHabiles = valorDia * 5;
		totalSabados = valorDia / 2;
		totalSemanal = totalDiasHabiles + totalSabados;
		
		System.out.println("El salario semanal es " + totalSemanal + "$");
		
		input.close();

	}

}
