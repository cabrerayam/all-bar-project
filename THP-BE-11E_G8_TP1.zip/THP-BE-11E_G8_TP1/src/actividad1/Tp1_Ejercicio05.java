/*
 * Realiza un programa que permita ingresar valores del mismo tipo para
 * las variables a y b. 
 * Una vez cargadas, mostrar ambas variables por pantalla, 
 * intercambia sus valores (que lo cargado en a quede en b, y viceversa) 
 * y volve a mostrarlas actualizadas.
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio05 {
	
	static final Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
	int a,b,x;
	
	System.out.println("Ingrese el valor de un n�mero");
	a = Integer.parseInt(input.nextLine());
	System.out.println("Ingrese el valor de otro n�mero");
	b = Integer.parseInt(input.nextLine());
	System.out.println("Los numeros ingresados son " + a + " y " + b);
	
	x = a;
	a = b;
	b = x;
	
	System.out.println("Los numeros ingresados intercambiados son " + a + " y " + b);
	
	input.close();
	
	}
}
