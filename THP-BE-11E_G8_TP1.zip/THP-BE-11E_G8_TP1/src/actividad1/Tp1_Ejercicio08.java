/*
 * Realiz� un programa que permita ingresar dos n�meros naturales. Debes mostrar los                      
resultados para las 4 operaciones matem�ticas b�sicas con los n�meros ingresados. 
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio08 {
	
	static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		int num1, num2, sum, rest, mult;
		double div;
	
		String mensajeResultado = "El resultado de la ";
		
		System.out.println("Por favor ingrese un numero");
		num1 = Integer.parseInt(input.nextLine());
		System.out.println("Por favor ingrese otro numero");
		num2 = Integer.parseInt(input.nextLine());
		
		sum = num1 + num2;
		rest = num1 - num2;
		mult = num1 * num2;
		div = (double) num1 / num2;
		
		System.out.println(mensajeResultado + "suma es " + sum);
		System.out.println(mensajeResultado + "resta es " + rest);
		System.out.println(mensajeResultado + "multiplicaci�n es " + mult);
		System.out.println(mensajeResultado + "divisi�n es " + div);
		
		input.close();
				
	}

}
