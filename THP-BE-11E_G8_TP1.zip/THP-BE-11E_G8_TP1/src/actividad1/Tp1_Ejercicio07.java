/*
 * Realiz� un programa que permita ingresar el ancho y el largo de un terreno en metros y el                                  
valor del metro cuadrado de tierra. 
Debe mostrarse el valor total del terreno y la cantidad de                                
metros de alambre para cercarlo completamente a tres alturas distintas.
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio07 {
	
	static final Scanner input = new Scanner(System.in);
	static final int NUMERO_DE_VUELTAS = 3;

	public static void main(String[] args) {
		
		double ancho, largo, valorMetroCuadrado, metrosAlambre, valorTotalTerreno;
		
		System.out.println("Ingrese el ancho del terreno");
		ancho = Double.parseDouble(input.nextLine());
		System.out.println("Ingrese el largo del terreno");
		largo = Double.parseDouble(input.nextLine());
		System.out.println("Ingrese el valor del metro cuadrado de tierra");
		valorMetroCuadrado = Double.parseDouble(input.nextLine());
		
		valorTotalTerreno = ancho * largo * valorMetroCuadrado;
		metrosAlambre = ((ancho + largo) * 2) * NUMERO_DE_VUELTAS;
		
		System.out.println("El valor total del terreno es " + valorTotalTerreno + "$");
		System.out.println("Para cercarlo a tres alturas distintas se necesitan " + metrosAlambre + " metros de alambre");
		
		input.close();
		
	}

}
