/*
 * Realiza un programa que permita ingresar el monto total de las ventas realizadas
 * por un vendedor durante el mes, de quien se sabe que gana un sueldo fijo de
 * 44000 pesos mas el 16 por ciento del monto total vendido. Con tales datos debes
 * calcular y mostrar el importe a cobrar por el vendedor.
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio06 {
	
	static final Scanner input = new Scanner(System.in);
	static final int SUELDO = 44000;
	static final double PORCENTAJE = 0.16;
			
	public static void main(String[] args) {
		
		double montoTotalVentas, importeACobrar;
		
		System.out.println("Ingrese el monto total de las ventas realizadas");
		montoTotalVentas = Double.parseDouble(input.nextLine());
		
		importeACobrar = SUELDO + (montoTotalVentas * PORCENTAJE);
		
		System.out.println("El importe a cobrar es " + importeACobrar + "$");

		input.close();
		
	}

}
