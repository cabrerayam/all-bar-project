/*Realiz� un programa que permita ingresar un n�mero entero. Debe mostrarse el n�mero ingresado:
a. Multiplicado por 5.
b. Dividido por 2.
 */
 
package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio03 {
	
	static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		int num;
		String mensajeResultado = "El resultado de ";
		System.out.println("Ingrese un numero");
		num = Integer.parseInt(input.nextLine());
		int resultMult = num * 5;
		double resultDiv = num / 2.0;
		System.out.println(mensajeResultado + num + " multiplicado por 5 es " + resultMult);
		System.out.println(mensajeResultado + num + " dividido entre 2 es " + resultDiv);
		input.close();		
	}

}

