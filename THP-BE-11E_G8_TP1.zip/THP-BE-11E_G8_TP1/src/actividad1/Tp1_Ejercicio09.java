/*
 *  Realiz� un programa que permita ingresar dos n�meros que representan las medidas en                        
grados de dos �ngulos interiores de cierto tri�ngulo. A partir de los valores de estos dos                              
�ngulos el programa debe mostrar el valor en grados del �ngulo restante. Record� que la                            
suma de los �ngulos interiores de todo tri�ngulo es de 180�.
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio09 {
	
	static final Scanner input = new Scanner(System.in);
	static final int SUMA_ANGULOS = 180;

	public static void main(String[] args) {
		
		double anguloA, anguloB, anguloC;
		
		System.out.println("Ingrese la medida en grados del primer �ngulo");
		anguloA = Double.parseDouble(input.nextLine());
		System.out.println("Ingrese la medida en grados del segundo �ngulo");
		anguloB = Double.parseDouble(input.nextLine());
		
		anguloC = SUMA_ANGULOS - (anguloA + anguloB);
		
		System.out.println("El valor en grados del angulo restante es " + anguloC);
		
		input.close();

	}

}
