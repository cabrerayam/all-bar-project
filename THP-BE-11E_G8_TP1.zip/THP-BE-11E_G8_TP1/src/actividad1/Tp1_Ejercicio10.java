/*
 * Realiz� un programa que permita resolver el siguiente problema: 
 * Tres personas aportan diferente capital a una sociedad y desean saber 
 * el valor total aportado y qu� porcentaje aport� cada una (indicando nombre y porcentaje).
 * Solicitar la carga por teclado del nombre de cada socio, 
 * su capital aportado y a partir de esto 
 * calcular e informar lo requerido previamente.
 */

package actividad1;

import java.util.Scanner;

public class Tp1_Ejercicio10 {
	
	static final Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		String nombreSocioA, nombreSocioB, nombreSocioC;
		Double aporteSocioA, aporteSocioB, aporteSocioC, totalAportado;
		
		System.out.println("Ingrese el nombre el primer socio");
		nombreSocioA = input.nextLine();
		System.out.println("Ingrese el aporte realizado por " + nombreSocioA);
		aporteSocioA = Double.parseDouble(input.nextLine());
		System.out.println("Ingrese el nombre el segundo socio");
		nombreSocioB = input.nextLine();
		System.out.println("Ingrese el aporte realizado por " + nombreSocioB);
		aporteSocioB = Double.parseDouble(input.nextLine());
		System.out.println("Ingrese el nombre el tercer socio");
		nombreSocioC = input.nextLine();
		System.out.println("Ingrese el aporte realizado por " + nombreSocioC);
		aporteSocioC = Double.parseDouble(input.nextLine());
		
		totalAportado = aporteSocioA + aporteSocioB + aporteSocioC;
		
		System.out.println("El valor total aportado es " + totalAportado + "$");
		System.out.println(nombreSocioA + " aport� el " + (aporteSocioA/totalAportado)*100 + "%");
		System.out.println(nombreSocioB + " aport� el " + (aporteSocioB/totalAportado)*100 + "%");
		System.out.println(nombreSocioC + " aport� el " + (aporteSocioC/totalAportado)*100 + "%");
		
		input.close();


	}

}
