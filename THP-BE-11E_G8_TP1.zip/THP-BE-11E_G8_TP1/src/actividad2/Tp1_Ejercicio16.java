/*
 * Realiz� un programa que permita ingresar la cantidad de inscriptos a una conferencia 
 * y la cantidad de asientos disponibles en el auditorio. 
 * Debes indicar si alcanzan los asientos, Si los asientos no alcanzaran 
 * indicar cu�ntos faltan para que todos los inscriptos puedan sentarse
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio16 {
	
	static final Scanner  input = new Scanner(System.in);

	public static void main(String[] args) {
		
		int cantInscriptos, cantAsientosDisp, cantAsientosFalt;
		
		System.out.println("Ingrese la cantidad de inscriptos");
		cantInscriptos = Integer.parseInt(input.nextLine());
		System.out.println("Ingrese la cantidad de asientos disponibles");
		cantAsientosDisp = Integer.parseInt(input.nextLine());
		
		if(cantInscriptos <= cantAsientosDisp) {
			System.out.println("Los asientos disponibles son suficientes");
		} else {
			cantAsientosFalt = cantInscriptos - cantAsientosDisp;
			System.out.println("Los asientos no son suficientes, faltan " + cantAsientosFalt + " asientos");
		}
		
		input.close();
		
	}

}
