/*
 * Para entrar a la monta�a rusa Miedo a las alturas, 
 * algo m�s chica y tranquila que la anterior,                
 * alcanza con que se cumpla solamente una de las siguientes condiciones: 
 * ser mayor de 6 a�os o medir m�s de 1,50 metros. 
 * Realiz� el mismo procedimiento que con el ejercicio anterior 
 * pero con los nuevos requisitos. 
 * Datos:
 * Nombre:Juan, Edad:5, Altura:1.45, �Entra al juego? = Falso
 * Nombre:Mar�a, Edad:7, Altura:1.23, �Entra al juego? = Verdadero
 * Nombre:Luis, Edad:8, Altura:1.51, �Entra al juego? = Verdadero
 * Nombre:Ana, Edad:9, Altura:1.39, �Entra al juego? = Verdadero
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio15 {
	
	static final Scanner input = new Scanner(System.in);
	static final int EDAD_MINIMA = 6;
	static final double ALTURA_MINIMA = 1.50;

	public static void main(String[] args) {
	
	String nombre; 
	int edad;
	double altura;
	boolean puedeEntrar;
	
	System.out.println("Ingrese el nombre");
	nombre = input.nextLine();
	System.out.println("Ingrese la edad");
	edad = Integer.parseInt(input.nextLine());
	System.out.println("Ingrese la altura");
	altura = Double.parseDouble(input.nextLine());
	
	puedeEntrar = edad > EDAD_MINIMA || altura > ALTURA_MINIMA;
	if (puedeEntrar) {
		System.out.println(nombre + " puede entrar");
	} else {
		System.out.println(nombre + " NO puede entrar");
	}
	
	input.close();

	}

}
