/*
 * Realiz� un programa para ingresar tres n�meros enteros 
 * e indique cu�l de ellos es el mayor y su valor.
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio13 {
	
	static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		int num1, num2, num3, mayor;
		String mensaje;
		
		System.out.println("Por favor ingrese un n�mero");
		num1 = Integer.parseInt(input.nextLine());
		System.out.println("Por favor ingrese otro n�mero");
		num2 = Integer.parseInt(input.nextLine());
		
		if(num1 > num2) {
			mayor = num1;
			mensaje = "El primer numero es el mayor y su valor es ";
			System.out.println(mensaje + mayor);
		} else {
			mayor = num2;
			mensaje = "El segundo numero es el mayor y su valor es ";
			System.out.println(mensaje + mayor);
		}
		System.out.println("Por favor ingrese un tercer n�mero");
		num3 = Integer.parseInt(input.nextLine());
		if (num3 > mayor) {
			mayor = num3;
			mensaje = "El tercer numero ingresado es el mayor y su valor es ";
		} 
		System.out.println(mensaje + mayor);
	
		input.close();
		
	}

}
