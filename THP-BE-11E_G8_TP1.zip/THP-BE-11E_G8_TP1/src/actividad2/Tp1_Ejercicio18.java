/*
 * Realiz� un programa que permita al usuario ingresar dos n�meros enteros. La computadora
debe indicar si el mayor es divisible por el menor. (Un n�mero entero a es divisible por un
n�mero entero b cuando el resto de la divisi�n entre a y b es 0 .
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio18 {
	
	static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		int a , b , mayor, menor;
		boolean esDivisible;
		
		System.out.println("Ingrese un numero entero");
		a = Integer.parseInt(input.nextLine());
		System.out.println("Ingrese otro numero");
		b = Integer.parseInt(input.nextLine());

		if (a > b) {
			mayor = a;
			menor = b;
		} else {
			mayor = b;
			menor = a;
		}
		
		esDivisible = mayor % menor == 0;
		
		if (esDivisible){
			System.out.println(mayor + " es divisible entre " + menor);
		} else {
			System.out.println(mayor + " no es divisible entre " + menor);
		}
		
		input.close();
	}

}
