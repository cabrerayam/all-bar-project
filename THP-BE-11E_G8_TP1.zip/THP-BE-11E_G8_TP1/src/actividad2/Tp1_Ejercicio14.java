/*
 * Para entrar a la monta�a rusa Infierno en las alturas 
 * se requiere tener al menos 7 a�os y medir m�s de 1,50 metros.
 * Complet� el siguiente cuadro a mano seg�n los requisitos y luego haz el
 * programa que permita, seg�n las edades y estaturas ingresadas por el usuario, 
 * obtener los mismos resultados seg�n los siguientes datos:
 * Nombre:Juan, Edad:5, Altura:1.45, �Entra al juego? = Falso
 * Nombre:Mar�a, Edad:7, Altura:1.23, �Entra al juego? = Falso
 * Nombre:Luis, Edad:8, Altura:1.51, �Entra al juego? = Verdadero
 * Nombre:Ana, Edad:9, Altura:1.39, �Entra al juego? = Falso
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio14 {
	
	static final Scanner input = new Scanner(System.in);
	static final int EDAD_MINIMA = 7;
	static final double ALTURA_MINIMA = 1.50;
	
	public static void main(String[] args) {
		
		String nombre;
		int edad;
		double altura;
		boolean puedeEntrar;
		
		System.out.println("Ingrese el nombre");
		nombre = input.nextLine();
		System.out.println("Ingrese la edad");
		edad = Integer.parseInt(input.nextLine());
		System.out.println("Ingrese la altura");
		altura = Double.parseDouble(input.nextLine());
		
		puedeEntrar = edad >= EDAD_MINIMA && altura > ALTURA_MINIMA;
		
		if (puedeEntrar){
			System.out.println(nombre + " puede entrar a la monta�a rusa");
		}else {
			System.out.println(nombre + " NO puede entrar a la monta�a rusa");
		}
		
		input.close();
		
	}

}
