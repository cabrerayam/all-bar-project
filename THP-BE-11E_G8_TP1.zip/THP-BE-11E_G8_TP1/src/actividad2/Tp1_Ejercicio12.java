/*
 *Realiz� un programa que permita ingresar dos n�meros enteros
 * e indique cu�l de ellos es el mayor.
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio12 {
	
    static final Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		
		int num1, num2;
		
		System.out.println("Por favor ingrese un n�mero entero");
		num1 = Integer.parseInt(input.nextLine());
		System.out.println("Por favor ingrese un otro n�mero entero");
		num2 = Integer.parseInt(input.nextLine());
		
		if(num1 > num2) {
			System.out.println("El n�mero mayor es " + num1);
		} else {
			System.out.println("El numero mayor es " + num2);
		}
		
		input.close();
		
	}

}
