/*
 * Realiz� un programa que permita ingresar dos n�meros enteros y la operaci�n a realizar
( '+' , '-' , '*' , '/' ). 
Debe mostrarse el resultado para la operaci�n ingresada. Considerar
que no se puede dividir por cero (en ese caso mostrar el texto 'ERROR' )
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio20 {
	
	static final Scanner input = new Scanner(System.in);
	static final String SUMA = "+";
	static final String RESTA = "-";
	static final String MULTIPLICACION = "*";
	static final String DIVISION = "/";
	
	public static void main(String[] args) {
		
		int a, b;
		String operacion;
		
		System.out.println("Por favor ingrese un numero entero");
		a = Integer.parseInt(input.nextLine());
		System.out.println("Por favor ingrese otro numero entero");
		b = Integer.parseInt(input.nextLine());
		System.out.println("Ingrese la operacion que desea realizar: " +  SUMA  + " " + RESTA + " " + MULTIPLICACION + " " +  DIVISION);
		operacion = input.nextLine();
		
		switch (operacion) {
		
		case SUMA:
			System.out.println("El resultado es " +  (a + b));
			break;
		case RESTA:
			System.out.println("El resultado es " + (a - b));
			break;
		case MULTIPLICACION:
			System.out.println("El resultado es " + (a * b));
			break;
		case DIVISION:
			if(b !=0 ) {
				System.out.println("El resultado es " + (a / b));
			} else {
				System.out.println("ERROR, no se puede dividir entre cero");
			}
			break;
		default: System.out.println("La operacion ingresada es incorrecta");
		break;
		
		
		}
		
		input.close();
		
	}

}
