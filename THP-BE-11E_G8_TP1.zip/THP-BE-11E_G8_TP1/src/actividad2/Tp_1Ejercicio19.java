/*Existen dos reglas que identifican dos conjuntos de valores:
a. El n�mero es de un solo d�gito.
b. El n�mero es impar.
A partir de estas reglas, realiz� un programa que permita ingresar un n�mero entero. 
Debe asignar el valor que corresponda a las variables booleanas esDeUnSoloDigito , esImpar ,
estaEnAmbos y noEstaEnNinguno el valor Verdadero o Falso , seg�n corresponda, para indicar si
el valor n�mero ingresado pertenece o no a cada conjunto. Defin� un lote de prueba de varios
n�meros y prob� el algoritmo, escribiendo los resultados tal como se hizo en los ejercicios
anteriores.
 */

package actividad2;

import java.util.Scanner;

public class Tp_1Ejercicio19 {
	
	static final Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		int numero;
		boolean esDeUnSoloDigito, esImpar, estaEnAmbos, noEstaEnNinguno;
		
		System.out.println("Por favor ingrese un numero entero");
		numero = Integer.parseInt(input.nextLine());
		
		esDeUnSoloDigito = numero > -10 && numero < 10; 
		esImpar = numero % 2 != 0;
		estaEnAmbos = esDeUnSoloDigito && esImpar;
		noEstaEnNinguno = !(esDeUnSoloDigito || esImpar);
		
		System.out.println("El numero ingresado es " + numero);
		System.out.println("El numero es impar " + esImpar);
		System.out.println("El numero esta en ambos conjuntos " + estaEnAmbos);
		System.out.println("El numero no esta en ninguno de los conjuntos " + noEstaEnNinguno);
		
		input.close();
		
	}

}
