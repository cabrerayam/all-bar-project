/*
 *Realiz� un programa que permita ingresar un n�mero entero 
 *e indique si se trata de un n�mero par o impar
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio11 {
	
	static final Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		int num;
		boolean esPar;
		
		System.out.println("Ingrese un numero entero");
		num = Integer.parseInt(input.nextLine());
		esPar = num % 2 == 0;
		if (esPar){
			System.out.println("Es un numero par");	
		} else {
			System.out.println("Es un numero impar");
		}
		
		input.close();
		
	}

}
