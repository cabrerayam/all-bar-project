/*Realiz� un programa que permita al usuario ingresar un n�mero entero entre 1 y 7 . Debe
mostrarse por pantalla el nombre del d�a de la semana que representa tal n�mero tomando
como el primer d�a de la semana el Domingo. De ingresar un n�mero fuera de rango debe
mostrar error.
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio21 {
	
	static final Scanner input = new Scanner(System.in);
	static final int DOMINGO = 1;
	static final int LUNES = 2;
	static final int MARTES = 3;
	static final int MIERCOLES = 4;
	static final int JUEVES = 5;
	static final int VIERNES = 6;
	static final int SABADO = 7;

	public static void main(String[] args) {
		
		int numDiaDeLaSemana;
		
		System.out.println("Ingrese un numero entero del 1 al 7 ");
		numDiaDeLaSemana = Integer.parseInt(input.nextLine());
		
		switch (numDiaDeLaSemana) {
		
		case DOMINGO:
			System.out.println("El numero ingresado corresponde al d�a domingo");
			break;
		case LUNES:
			System.out.println("El numero ingresado corresponde al d�a lunes");
			break;
		case MARTES:
			System.out.println("El numero ingresado corresponde al d�a martes");
			break;
		case MIERCOLES:
			System.out.println("El numero ingresado corresponde al d�a mi�rcoles");
			break;
		case JUEVES:
			System.out.println("El numero ingresado corresponde al d�a jueves");
			break;
		case VIERNES:
			System.out.println("El numero ingresado corresponde al d�a viernes");
			break;
		case SABADO: 
			System.out.println("El numero ingresado corresponde al d�a sabado");
			break;
		default: 
			System.out.println("El numero ingresado es invalido");
			break;
		}
		
		input.close();
		
	}

}
