/*
 * Realiz� un programa que permita ingresar una edad (entre 1 y 120 a�os) 
 * y un g�nero ('F'para mujeres,'M' para hombres). 
 * En caso de haber ingresado valores err�neos 
 * (edad fuera de rango o g�nero inv�lido), informar tal situaci�n. 
 * Si los datos est�n bien ingresados el programa debe indicar, 
 * sabiendo que las mujeres se jubilan con 60 a�os o m�s 
 * y los hombres con 65 a�os o m�s, si la persona est� en edad de jubilarse.
 */

package actividad2;

import java.util.Scanner;

public class Tp1_Ejercicio17 {

	static final Scanner input = new Scanner(System.in);
	static final int EDAD_MINIMA = 1;
	static final int EDAD_MAXIMA = 120;
	static final String MASCULINO = "M";
	static final String FEMENINO = "F";
	static final int EDAD_JUB_M = 65;
	static final int EDAD_JUB_F = 60;

	public static void main(String[] args) {

		int edad;
		String genero;

		System.out.println("Ingrese la edad");
		edad = Integer.parseInt(input.nextLine());

		if (edad < EDAD_MINIMA || edad > EDAD_MAXIMA) {
			System.out.println("La edad ingresada es incorrecta");
		} else {
			System.out.println("Ingrese el genero, masculino o femenino");
			genero = input.nextLine();
			
			switch (genero.toUpperCase()) {
			
			case MASCULINO:
			if (edad > EDAD_JUB_M) {
				System.out.println("Puede jubilarse");
			} else {
				System.out.println("No puede jubilarse");
			}
			break;

			case FEMENINO:
			if (edad > EDAD_JUB_F) {
				System.out.println("Puede jubilarse");
			} else {
				System.out.println("No puede jubilarse");
			}
			break;
			
			default:
			System.out.println("El genero ingresado es invalido");
		}
		
		input.close();

		}
		
	}

}
