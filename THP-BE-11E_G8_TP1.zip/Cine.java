package clase20210414;

import java.util.Scanner;

public class Cine {

	static final Scanner input = new Scanner(System.in);
	static final int VALOR_ADULTO = 500;
	static final int VALOR_MENOR = 300;
	static final String USUARIO = "admin";
	static final String CLAVE = "boletos";
	static final int CANTIDAD_MINIMA = 0;
	static final char CONTINUAR = 'S';
	static final char NO_CONTINUAR = 'N';
	
	public static void main(String[] args) {
	
		String	nombrePelicula;
		int cantAdultos;
		int cantMenores;
		char continuar;
		String usuarioIngresado;
		String claveIngresada;
		String peliMayorBoletos;
		String peliMayorRecaudacion;
		int	mayorBoletos;
		double mayorRecaudacion;
		double recaudacion;
		int totalBoletos;
		int totalEntradasAdultos;
		int totalEntradasMenores;

		// Inicializo contadores y acumuladores globales
		totalEntradasAdultos = 0;
		totalEntradasMenores = 0;
		
		// Inicializo variables para calculo de mayor
		mayorBoletos = Integer.MIN_VALUE;
		mayorRecaudacion = Double.MIN_VALUE;
		peliMayorBoletos = "";
		peliMayorRecaudacion = "";
		
		// Ingreso de usuario y clave con validación
		System.out.println("Ingrese usuario");
		usuarioIngresado=input.nextLine();
		System.out.println("Ingrese clave");
		claveIngresada=input.nextLine();
		while(!usuarioIngresado.equalsIgnoreCase(USUARIO) || !claveIngresada.equals(CLAVE)) {
			System.out.println("Error, usuario y/o password incorrectos");
			System.out.println("Ingrese usuario");
			usuarioIngresado=input.nextLine();
			System.out.println("Ingrese clave");
			claveIngresada=input.nextLine();
		}
		
		System.out.println("Bienvenidos al Cine");
		
		do {
			// Ingreso nombre pelicula
			System.out.println("Nombre Película");
			nombrePelicula=input.nextLine();		
			
			// Ingreso cantidad de adultos
			do {
				System.out.println("Ingrese cantidad de adultos");
				cantAdultos=Integer.parseInt(input.nextLine());
			} while (cantAdultos < CANTIDAD_MINIMA);
			
			// Ingreso cantidad de menores
			do {
				System.out.println("Ingrese cantidad de menores");
				cantMenores=Integer.parseInt(input.nextLine());
			} while (cantMenores < CANTIDAD_MINIMA);
			
			// Calculamos recaudacion y boletos
			recaudacion = cantAdultos * VALOR_ADULTO + cantMenores * VALOR_MENOR;
			totalBoletos = cantAdultos + cantMenores;
			
			// Sumarizo total entradas de adultos y menores
			totalEntradasAdultos = totalEntradasAdultos + cantAdultos;
			totalEntradasMenores += cantMenores;
			
			// Verifico pelicula de mayor cantidad de boletos vendidos
			if (totalBoletos > mayorBoletos) {
				mayorBoletos = totalBoletos;
				peliMayorBoletos = nombrePelicula;				
			}
			
			// Verifico pelicula con mayor recaudacion
			if (recaudacion > mayorRecaudacion) {
				mayorRecaudacion = recaudacion;
				peliMayorRecaudacion = nombrePelicula;				
			}
			System.out.println("Recaudacion de " + nombrePelicula + " $ " + recaudacion);
			// Pregunto si desea continuar
			do {
				System.out.println("Desea continuar? S/N");
				continuar=input.nextLine().toUpperCase().charAt(0);
			} while (continuar != CONTINUAR && continuar!=NO_CONTINUAR);
			
		} while (continuar==CONTINUAR);
		
		// Mostrar totales	
		System.out.println("Pelicula con mayor cantidad de boletos vendidos: " + peliMayorBoletos);
		System.out.println("Pelicula con mayor recaudacion: " + peliMayorRecaudacion);
		System.out.println("Boletos de adultos vendidos: " + totalEntradasAdultos);
		System.out.println("Boletos de menores vendidos: " + totalEntradasMenores);
	
	}

}
